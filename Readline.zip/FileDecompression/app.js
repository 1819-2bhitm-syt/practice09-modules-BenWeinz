const readline = require('readline');
const fs = require('fs');

const rl = readline.createInterface({
    input: fs.createReadStream('compressed.txt'),
    crlfDelay: Infinity
});
let compressedLines = [];
rl.on('line', (line) => {
    compressedLines.push(line);
});

rl.on('close', () => {
    for (line of compressedLines){

        decompress(line);


    }
});

function decompress(line){
    let firstChar = line.charAt(0);
    let secondChar = line.substring(1,line.length);

    secondChar = parseInt(secondChar);

    while(secondChar > 0){
        console.log(firstChar);
        secondChar--;
    }
    console.log();
}