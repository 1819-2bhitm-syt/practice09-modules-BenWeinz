const readline = require('readline');
const fs = require('fs');

console.log('----------------------------------');
console.log('email addresses');
console.log('----------------------------------');

const rl = readline.createInterface({
    input: fs.createReadStream('teachers.csv'),
    crlfDelay: Infinity
});
let vNames = [];
let nNames = [];
let i = 0;
let j = 0;
rl.on('line', (line) => {
    while(line.charAt(j-1) != ';') {
        nNames[i] = line.substring(0, j);
        j++;
    }
    j=0;
    while(line.charAt(j) != ';'){
        vNames[i] = line.substring(j+2, line.length);
        j++;
    }

    let email = getMailAddress(vNames[i], nNames[i]);

    console.log(email);
    i++;
    j=0;

});


function getMailAddress(firstName, lastName){

    lastName = lastName.replace("ä", "ae");
    lastName = lastName.replace("ü", "ue");
    lastName = lastName.replace("ö", "oe");

    let email;
    email = firstName.charAt(0) + '.' +  lastName + '@htl-leonding.ac.at';

    email = email.toLowerCase();
    return email;
}

